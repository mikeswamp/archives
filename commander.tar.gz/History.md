
1.2.1 / 2013-01-08 
==================

  * add freeing of normalized argv
  * dont worry about zeroing in command_free()
  * fix docs

1.2.0 / 2013-01-08 
==================

  * add command_free()

1.1.0 / 2012-12-18 
==================

  * add short flag expansion

1.0.0 / 2012-12-13 
==================

  * fix malloc(), add a byte for nul
 
0.0.1 / 2012-06-16 
==================

  * Initial release
